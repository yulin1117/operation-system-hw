#include <stdio.h>
#include <stdlib.h>

#define MIN_PID 0
#define MAX_PID 127
#define BITS_PER_INT 32


int bitmap[4] = {0};

// Function to allocate a bitmap
int allocate_map(void) {
    for (int i = 0; i < 4; i++) {
        if (bitmap[i] != 0) {
            return -1; // Bitmap already allocated
        }
    }
    return 1;
}

// Function to print each bitmap decimal value
void print_bitmap(void) {
    for (int k = 0; k < 4; k++) {
        unsigned int value = bitmap[k]; // 直接获取整个32位整数
        printf("bitmap[%d] = %u\n", k, value);
    }
}

// Function to allocate a PID
int allocate_pid(void) {
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < BITS_PER_INT; j++) {
            if (!(bitmap[i] & (1 << j))) { // If bit is 0, PID is available
                bitmap[i] |= (1 << j); // Set the bit to 1 (allocate PID)
                return i * BITS_PER_INT + j; // Return the allocated PID
            }
        }
    }
    return -1; // No available PID
}

// Function to release a PID
void release_pid(int pid) {
    if (pid < MIN_PID || pid > MAX_PID) {
        printf("Invalid PID\n");
        return;
    }

    int index = pid / BITS_PER_INT;
    int bit = pid % BITS_PER_INT;

    if (bitmap[index] & (1 << bit)) {
        bitmap[index] &= ~(1 << bit); // Release the PID by setting the bit to 0
        print_bitmap();
    } else {
        printf("This PID is not allocated\n");
    }
}


int main(void) {
    int choice, pid;
    

    if (allocate_map() == -1) {
        printf("Error: Bitmap already allocated\n");
        return 1;
    }
    printf("----Allocating Bitmap----\n");
    print_bitmap();

    while (1) {
        printf("------------------------\n");
        printf("(1) Create a process\n");
        printf("(2) Delete a process\n");
        printf("(3) Exit\n");
        printf("Please enter your choice:\n");

        scanf("%d", &choice);

        switch (choice) {
            case 1:
                pid = allocate_pid();
                if (pid != -1) {
                    printf("Successful to allocate PID. The PID of new process: %d\n", pid);
                    print_bitmap();
                    
                    
                } else {
                    printf("No available PID\n");
                }
                break;
            case 2:
                printf("Please enter the PID you want to delete:\n");
                scanf("%d", &pid);
                release_pid(pid);
                break;
            case 3:
                printf("Exit this Process!\n");
                return 0;

            default:
                printf("Invalid choice\n");
                while (getchar() != '\n');
                break;
        }
    }

    return 0;
}
