#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <time.h>

pthread_mutex_t mutex;
int bitmap[4] = {0};

#define MIN_PID 0
#define MAX_PID 127
#define BITS_PER_INT 32

// Function to allocate a bitmap
int allocate_map(void)
{
    for (int i = 0; i < 4; i++)
    {
        if (bitmap[i] != 0)
        {
            return -1; // Bitmap already allocated
        }
    }
    return 1;
}

// Function to allocate a PID
int allocate_pid(void)
{
    int PID;
    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < BITS_PER_INT; j++)
        {
            if (!(bitmap[i] & (1 << j)))
            {                          // If bit is 0, PID is available
                bitmap[i] |= (1 << j); // Set the bit to 1 (allocate PID)
                PID = i * BITS_PER_INT + j;
                return PID; // Return the allocated PID
            }
        }
    }
    return -1; // No available PID
}

// Function to print each bitmap decimal value
void print_bitmap(void)
{
    for (int k = 0; k < 4; k++)
    {
        unsigned int value = bitmap[k]; // 直接获取整个32位整数
        printf("bitmap[%d] = %u\n", k, value);
    }
}

// Function to release a PID
void release_pid(int pid)
{
    if (pid < MIN_PID || pid > MAX_PID)
    {
        printf("Invalid PID\n");
        return;
    }

    int index = pid / BITS_PER_INT;
    int bit = pid % BITS_PER_INT;

    if (bitmap[index] & (1 << bit))
    {
        bitmap[index] &= ~(1 << bit); // Release the PID by setting the bit to 0
    }
    else
    {
        printf("This PID is not allocated\n");
    }
}

// Thread start routine
void *thread_routine(void *arg)
{
    int PID;
    int s;
    s = (rand() % 10) + 1;
    pthread_mutex_lock(&mutex);
    PID = allocate_pid();
    pthread_mutex_unlock(&mutex);
    if (PID != -1)
    {
        printf("Thread ID=%lu\npid=%d,this thread will sleep %d seconds\nRelease Pid %d\n", pthread_self(), PID, s, PID);
        sleep(s); // Sleep for a random period (1-10 seconds)
        pthread_mutex_lock(&mutex);
        release_pid(PID);
        pthread_mutex_unlock(&mutex);
    }
    else
    {
        printf("No available PID\n");
    }

    pthread_exit(NULL);
}

int main(void)
{
    pthread_mutex_init(&mutex, NULL);
    int choice;
    print_bitmap();

    while (1)
    {
        printf("(1).Create 100 process\n");
        printf("(2).exit\n");
        printf("Please enter your choice:\n");

        scanf("%d", &choice);

        switch (choice)
        {
        case 1:
            srand(time(NULL));

            if (allocate_map() == -1)
            {
                printf("Error: Bitmap already allocated\n");
                return 1;
            }

            pthread_t threads[100];

            for (int i = 0; i < 100; i++)
            {
                pthread_create(&threads[i], NULL, thread_routine, NULL);
            }

            // 等待所有線程結束
            for (int i = 0; i < 100; i++)
            {
                pthread_join(threads[i], NULL);
            }

            printf("released Bitmap.\n");
            print_bitmap();
            pthread_mutex_destroy(&mutex);

            break;

        case 2:
            printf("Exit this Process!\n");
            return 0;

        default:
            printf("Invalid choice\n");
            while (getchar() != '\n')
                ;
            break;
        }
    }

    return 0;
}
